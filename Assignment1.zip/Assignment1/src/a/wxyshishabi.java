package a;
import java.util.Scanner;
public class wxyshishabi {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
