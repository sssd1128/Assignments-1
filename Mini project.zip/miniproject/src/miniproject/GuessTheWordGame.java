package miniproject;

import java.util.Scanner;
import java.util.Random;

public class GuessTheWordGame {
    public static void main(String[] args) {
      
        String[] words = {"java", "python", "ruby", "javascript", "html"};

      
        Random random = new Random();
        String selectedWord = words[random.nextInt(words.length)];
        char[] guessedWord = new char[selectedWord.length()];

       
        for (int i = 0; i < guessedWord.length; i++) {
            guessedWord[i] = '_';
        }

        
        int attemptsLeft = 10;
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Guess the Word Game!");
        System.out.println("You have " + attemptsLeft + " attempts to guess the word.");

        while (attemptsLeft > 0) {
            
            System.out.print("Current word: ");
            System.out.println(guessedWord);
            System.out.println("Attempts left: " + attemptsLeft);
            System.out.print("Enter a letter: ");

           
            char guess = scanner.next().toLowerCase().charAt(0);
            boolean correctGuess = false;

           
            for (int i = 0; i < selectedWord.length(); i++) {
                if (selectedWord.charAt(i) == guess) {
                    guessedWord[i] = guess;
                    correctGuess = true;
                }
            }

           
            if (correctGuess) {
                System.out.println("Correct guess!");
            } else {
                System.out.println("Wrong guess!");
                attemptsLeft--; 
            }

           
            if (String.valueOf(guessedWord).equals(selectedWord)) {
                System.out.println("Congratulations! You guessed the word: " + selectedWord);
                break;
            }
        }

       
        if (attemptsLeft == 0) {
            System.out.println("Game Over! The word was: " + selectedWord);
        }

        scanner.close();
    }
}