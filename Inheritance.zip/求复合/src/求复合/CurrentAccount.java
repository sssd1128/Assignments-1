package 求复合;

public class CurrentAccount {
	 public String accountNbr;
	    public String name;
	    protected double balance;
	    
	    public CurrentAccount(String accountNbr, String name, double balance) {
	        this.accountNbr = accountNbr;
	        this.name = name;
	        this.balance = balance;
	    }

	    public void display() {
	        System.out.println("Account Number: " + accountNbr);
	        System.out.println("Account Holder: " + name);
	        System.out.println("Balance: " + balance);
	    }
	    
	    public void deposit(double amount) {
	        if (amount > 0) {
	            balance += amount;
	            System.out.println("Deposited: " + amount);
	        } else {
	            System.out.println("Invalid deposit amount!");
	        }
	    }

	    public void withdraw(double amount) {
	        if (amount > 0 && amount <= balance) {
	            balance -= amount;
	            System.out.println("Withdrawn: " + amount);
	        } else {
	            System.out.println("Insufficient balance or invalid amount!");
	        }
	    }
	}

class SavingAccount extends CurrentAccount {

	public SavingAccount(String accountNbr, String name, double balance) {
        super(accountNbr, name, balance);
    }
	
	public void addInterest(double interestRate) {
        double interest = balance * interestRate / 100;
        balance += interest;
        System.out.println("Interest added: " + interest);
    }

public static void main(String[] args) {
    	SavingAccount myAccount = new SavingAccount("123456", "John Doe", 5000);
    	
    	 myAccount.display();
    	 
    	 myAccount.deposit(1000);
         myAccount.display();
         
         myAccount.withdraw(2000);
         myAccount.display();
         
         myAccount.addInterest(5);
         myAccount.display();
     }
 }